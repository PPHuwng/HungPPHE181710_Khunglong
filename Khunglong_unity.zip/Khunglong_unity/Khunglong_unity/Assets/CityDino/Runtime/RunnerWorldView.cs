using System;
using System.Collections.Generic;
using UnityEngine;

namespace CityDino
{
    /// <summary>
    /// World art in the same virtual canvas as RunnerSession. Layers and effects
    /// never move collision geometry: every player/hazard position comes from core.
    /// </summary>
    public sealed partial class RunnerWorldView : IDisposable
    {
        private const float Width = RunnerSession.CanvasWidth;
        private const float Height = RunnerSession.CanvasHeight;
        private const float GroundY = RunnerSession.GroundY;

        private readonly RunnerArt art;
        private readonly Texture2D circle;
        private readonly Texture2D glow;
        private readonly Texture2D spike;
        private readonly Texture2D saw;
        private readonly Texture2D ice;
        private readonly List<Vector2> gaps = new List<Vector2>(12);
        private GUIStyle signStyle;
        private District shownDistrict = District.Day;
        private Palette previousPalette;
        private Palette nextPalette;
        private float transitionStarted = -10f;
        private float paletteClock = -1f;
        private float stormVeil = .2f;
        private const float DistrictFadeDuration = 3f;
        private bool initialized;

        private struct Palette
        {
            public Color Sky, Horizon, Backdrop, FarCity, Foundation, Road, Accent;
            public float Rain, Snow, Night, Skyway, Sunset;
        }

        public RunnerWorldView(RunnerArt art)
        {
            this.art = art ?? throw new ArgumentNullException(nameof(art));
            circle = MakeCircle(false);
            glow = MakeCircle(true);
            spike = MakeSpike();
            saw = MakeSaw();
            ice = MakeIcicle();
        }

        public void Draw(RunnerSession session, float ambientTime)
        {
            if (session == null || (Event.current != null && Event.current.type != EventType.Repaint)) return;
            Color oldColor = GUI.color;
            Matrix4x4 oldMatrix = GUI.matrix;
            try
            {
                if (session.IsBossArena)
                {
                    DrawBossArena(session);
                    return;
                }
                bool menu = session.State == RunState.Menu;
                float scroll = menu ? ambientTime * 75f : session.Distance;
                float clock = menu ? ambientTime : session.Elapsed;
                Palette palette = CurrentPalette(session.CurrentDistrict, clock);
                float sceneryScroll = DecorativeScroll(scroll);
                DrawSky(palette, sceneryScroll, clock);
                DrawCity(palette, sceneryScroll, clock);
                DrawDistrictAtmosphere(session.CurrentDistrict, palette, sceneryScroll, clock,
                    session.Speed / RunnerSession.InitialSpeed);
                ReadGaps(session);
                DrawRoad(palette, scroll, session.Speed / RunnerSession.InitialSpeed);
                if (!menu)
                {
                    DrawEntities(session, palette, clock);
                    for (int i = 0; i < session.RunMissiles.Count; i++)
                    {
                        RunMissile missile = session.RunMissiles[i];
                        if (!missile.Removed) DrawRunMissileBody(missile.Id, missile.X, missile.Y,
                            missile.Width, missile.Height, missile.VelocityX, missile.Radius, clock);
                    }
                    DrawDino(session, session.PlayerAnimationTime);
                }
                if (!menu)
                {
                    DrawWind(session, clock);
                    if (session.CurrentDistrict == District.Storm)
                        stormVeil = RunnerWeather.GetStormDarkness(session.DistrictElapsed);
                    if (palette.Rain > .001f)
                        Fill(new Rect(0f, 0f, Width, Height),
                            new Color(0.025f, 0.04f, 0.075f, stormVeil * palette.Rain));
                    DrawLightning(session, palette.Rain);
                }
                // Storm rain stays in front of both the dark veil and flash.
                DrawWeather(palette, sceneryScroll, clock);
                if (!menu)
                {
                    for (int i = 0; i < session.RunMissileWarnings.Count; i++)
                        DrawRunMissileWarning(session.RunMissileWarnings[i], clock);
                    DrawDarkness(session);
                }
            }
            finally
            {
                GUI.color = oldColor;
                GUI.matrix = oldMatrix;
            }
        }

        private Palette CurrentPalette(District district, float time)
        {
            // A run clock rewind means restart/menu -> play. Never blend from a
            // previous run's late palette using a now-negative elapsed time.
            if (!initialized || time < paletteClock)
            {
                shownDistrict = district;
                previousPalette = nextPalette = ForDistrict(district);
                initialized = true;
                transitionStarted = time - DistrictFadeDuration;
            }
            paletteClock = time;
            if (shownDistrict != district)
            {
                previousPalette = Lerp(previousPalette, nextPalette,
                    Mathf.SmoothStep(0f, 1f, (time - transitionStarted) / DistrictFadeDuration));
                nextPalette = ForDistrict(district);
                shownDistrict = district;
                transitionStarted = time;
            }
            return Lerp(previousPalette, nextPalette,
                Mathf.SmoothStep(0f, 1f, (time - transitionStarted) / DistrictFadeDuration));
        }

        // Only painted scenery is capped. Entity movement, terrain openings,
        // scored distance and the runner's unbounded acceleration are unchanged.
        // Integrating the capped speed keeps phase continuous at the cap, unlike
        // multiplying the entire accumulated distance by a changing scale.
        private static float DecorativeScroll(float distance)
        {
            const double cap = 600d;
            double initial = RunnerSession.InitialSpeed, acceleration = RunnerSession.SpeedAcceleration;
            double d = Math.Max(0d, distance);
            double capTime = (cap - initial) / acceleration;
            double capDistance = initial * capTime + .5d * acceleration * capTime * capTime;
            if (d <= capDistance) return (float)d;
            double time = (Math.Sqrt(initial * initial + 2d * acceleration * d) - initial) / acceleration;
            return (float)(capDistance + (time - capTime) * cap);
        }

        private static Palette ForDistrict(District district)
        {
            Palette p = new Palette
            {
                Sky = Hex(0x86c9df), Horizon = Hex(0xf0ead4), Backdrop = Color.white,
                FarCity = Hex(0x8aaabf), Foundation = Hex(0x17283e), Road = Color.white,
                Accent = Hex(0x70e5d1)
            };
            switch (district)
            {
                case District.Snow:
                    p.Sky = Hex(0x8ca9c6); p.Horizon = Hex(0xe8f4fc); p.Backdrop = Hex(0xc6dded);
                    p.FarCity = Hex(0x7698b6); p.Road = Hex(0xc8e5f4); p.Accent = Hex(0xb9f4ff); p.Snow = 1f;
                    break;
                case District.Sunset:
                    p.Sky = Hex(0xf1b568); p.Horizon = Hex(0xffe2a7); p.Backdrop = Hex(0xffd8b0);
                    p.FarCity = Hex(0xc19c91); p.Road = Hex(0xf7d1a4); p.Accent = Hex(0xffc475); p.Sunset = 1f;
                    break;
                case District.Night:
                    p.Sky = Hex(0x101b37); p.Horizon = Hex(0x3c466b); p.Backdrop = Hex(0x91a5d5);
                    p.FarCity = Hex(0x303c64); p.Foundation = Hex(0x101b2f); p.Road = Hex(0xabbada);
                    p.Accent = Hex(0x89ffe4); p.Night = 1f;
                    break;
                case District.Skyway:
                    p.Sky = Hex(0x7bb4df); p.Horizon = Hex(0xe7edf6); p.Backdrop = Hex(0xc9e8ff);
                    p.FarCity = Hex(0x8daccb); p.Road = Hex(0xe2edf9); p.Accent = Hex(0xffdc8d); p.Skyway = 1f;
                    break;
                case District.Storm:
                    p.Sky = Hex(0x29354f); p.Horizon = Hex(0x74899e); p.Backdrop = Hex(0x9caed2);
                    p.FarCity = Hex(0x4f6382); p.Foundation = Hex(0x142137); p.Road = Hex(0x94aec7);
                    p.Accent = Hex(0x94ecf6); p.Rain = 1f; p.Night = 0.4f;
                    break;
            }
            return p;
        }

        private static Palette Lerp(Palette a, Palette b, float t)
        {
            t = Mathf.Clamp01(t);
            return new Palette
            {
                Sky = Color.Lerp(a.Sky, b.Sky, t), Horizon = Color.Lerp(a.Horizon, b.Horizon, t),
                Backdrop = Color.Lerp(a.Backdrop, b.Backdrop, t), FarCity = Color.Lerp(a.FarCity, b.FarCity, t),
                Foundation = Color.Lerp(a.Foundation, b.Foundation, t), Road = Color.Lerp(a.Road, b.Road, t),
                Accent = Color.Lerp(a.Accent, b.Accent, t), Rain = Mathf.Lerp(a.Rain, b.Rain, t),
                Snow = Mathf.Lerp(a.Snow, b.Snow, t),
                Night = Mathf.Lerp(a.Night, b.Night, t), Skyway = Mathf.Lerp(a.Skyway, b.Skyway, t),
                Sunset = Mathf.Lerp(a.Sunset, b.Sunset, t)
            };
        }

        private void DrawSky(Palette p, float scroll, float time)
        {
            for (int i = 0; i < 40; i++)
            {
                float fraction = i / 39f;
                Fill(new Rect(0f, i * Height / 40f, Width, Height / 40f + 1f), Color.Lerp(p.Sky, p.Horizon, fraction));
            }
            if (p.Night > 0.1f)
            {
                for (int i = 0; i < 46; i++)
                {
                    float x = Repeat(i * 173.71f + 73f, Width);
                    float y = 93f + Repeat(i * 53.13f, 230f);
                    float alpha = p.Night * (0.28f + 0.42f * (0.5f + Mathf.Sin(time * 1.1f + i) * 0.5f));
                    float size = i % 5 == 0 ? 3f : 2f;
                    Fill(new Rect(x, y, size, size), new Color(0.92f, 0.97f, 1f, alpha));
                }
            }
            float celestialY = 152f;
            Color sun = Color.Lerp(Hex(0xffe8b0), Hex(0xe6f7ff), p.Night);
            sun.a = Mathf.Lerp(0.94f, 0.2f, Mathf.Max(p.Rain, p.Snow * 0.65f));
            Disc(new Rect(974f, celestialY - 55f, 225f, 225f), WithAlpha(sun, sun.a * 0.24f), true);
            Disc(new Rect(1040f, celestialY + 5f, 88f, 88f), sun);
            if (p.Night > 0.4f)
                Disc(new Rect(1063f, celestialY - 5f, 78f, 78f), WithAlpha(p.Sky, p.Night));
            for (int i = 0; i < 7; i++)
            {
                float x = Repeat(i * 247f - scroll * 0.035f + time * 2f, 1550f) - 160f;
                float y = 145f + (i % 3) * 52f;
                float size = 0.6f + (i % 3) * 0.18f;
                Cloud(x, y, size, new Color(1f, 1f, 1f, Mathf.Lerp(0.56f, 0.1f, p.Night) * (1f - p.Rain * 0.5f)));
            }
        }

        private void DrawCity(Palette p, float scroll, float time)
        {
            // Fixed geometry is essential here: changing skyline height also
            // changes tile width and its modulo phase, making the entire city
            // lurch sideways/upward while entering or leaving the cloud map.
            const float baseY = 552f;
            float cityVisibility = 1f - p.Skyway * .72f;
            // Sparse silhouettes stay furthest away; they never contain a painted sky or road.
            for (int i = -1; i < 21; i++)
            {
                int variant = (i + 99) % 9;
                float x = i * 79f - Repeat(scroll * 0.035f, 79f);
                float height = 76f + (variant * 37 % 164);
                Color tint = WithAlpha(p.FarCity, 0.3f * cityVisibility);
                Fill(new Rect(x, baseY - height - 40f, 52f + variant % 3 * 11f, height), tint);
                Fill(new Rect(x + 20f, baseY - height - 57f, 15f, 17f), tint);
            }

            if (art.SkylineFar != null)
                DrawSkyline(art.SkylineFar, art.SkylineFarUV, 335f, baseY - 8f,
                    scroll * 0.075f, WithAlpha(Color.Lerp(Color.white, p.Backdrop, 0.45f), 0.65f * cityVisibility));
            else
                DrawProceduralSkyline(p, scroll, baseY, false);

            // Haze sits BETWEEN layers rather than hiding the player/obstacles.
            for (int i = 0; i < 8; i++)
                Fill(new Rect(0f, baseY - 152f + i * 19f, Width, 20f), WithAlpha(p.Horizon, (i / 7f) * 0.1f));

            if (art.SkylineNear != null)
                DrawSkyline(art.SkylineNear, art.SkylineNearUV, 285f, baseY,
                    scroll * 0.17f, WithAlpha(Color.Lerp(Color.white, p.Backdrop, 0.28f), 0.72f * cityVisibility));
            else
                DrawProceduralSkyline(p, scroll, baseY, true);

            // Tiny passing light strips reinforce movement without resembling hazards.
            const float viaductY = 512f;
            Fill(new Rect(0f, viaductY, Width, 3f), WithAlpha(p.FarCity, 0.25f * cityVisibility));
            for (int i = 0; i < 11; i++)
            {
                float x = Repeat(i * 153f - scroll * 0.32f, Width + 170f) - 100f;
                Fill(new Rect(x, viaductY - 3f, 42f, 2f), WithAlpha(p.Accent, (0.2f + p.Night * 0.1f) * cityVisibility));
            }
            if (p.Skyway > 0.1f)
            {
                for (int i = 0; i < 6; i++)
                {
                    float x = Repeat(i * 310f - scroll * 0.13f, 1680f) - 180f;
                    Cloud(x, 615f + i % 2 * 46f, 1.4f, new Color(0.96f, 0.98f, 1f, p.Skyway * 0.65f));
                }
            }
            if (p.Skyway < 0.98f)
            {
                float x = 1050f - Repeat(scroll * 0.3f, 1660f);
                if (x > -140f)
                {
                    float signAlpha = 1f - p.Skyway;
                    Fill(new Rect(x + 10f, 502f, 4f, 58f), WithAlpha(Hex(0x344c60), 0.48f * signAlpha));
                    Fill(new Rect(x, 479f, 107f, 28f), WithAlpha(Hex(0x203648), 0.75f * signAlpha));
                    Fill(new Rect(x + 3f, 482f, 101f, 22f), WithAlpha(p.Accent, 0.9f * signAlpha));
                    Sign(new Rect(x + 4f, 483f, 99f, 20f), "DINO / CITY", WithAlpha(Hex(0x203648), signAlpha), 12);
                }
            }
        }

        private static void DrawSkyline(Texture2D texture, Rect source, float height, float bottom, float scroll, Color tint)
        {
            // Preserve the buildings' proportions after trimming transparent sky/feet.
            float aspect = source.width * texture.width / Mathf.Max(1f, source.height * texture.height);
            float tileWidth = Mathf.Max(1f, aspect * height);
            float start = -Repeat(scroll, tileWidth);
            int tile = (int)Math.Floor(scroll / tileWidth);
            GUI.color = tint;
            for (float x = start; x < Width; x += tileWidth, tile++)
            {
                // Alternate reflections join identical edge pixels and avoid a hard panorama seam.
                Rect uv = (tile & 1) == 0 ? source : new Rect(source.x + source.width, source.y, -source.width, source.height);
                GUI.DrawTextureWithTexCoords(new Rect(x, bottom - height, tileWidth + 1f, height), texture, uv, true);
            }
        }

        private static void DrawProceduralSkyline(Palette p, float scroll, float bottom, bool near)
        {
            float spacing = near ? 118f : 86f;
            float parallax = near ? 0.16f : 0.07f;
            for (int i = -1; i < 16; i++)
            {
                int index = i + 60;
                float x = i * spacing - Repeat(scroll * parallax, spacing);
                float height = 78f + index * (near ? 39 : 31) % (near ? 170 : 210);
                Color tint = Color.Lerp(p.FarCity, p.Foundation, near ? 0.28f : 0.04f);
                tint.a = (near ? 0.58f : 0.4f) * (1f - p.Skyway * .72f);
                float width = spacing - 16f - index % 3 * 9f;
                Fill(new Rect(x, bottom - height, width, height), tint);
                Fill(new Rect(x + width * 0.3f, bottom - height - 10f, width * 0.4f, 10f), tint);
                for (int row = 0; row < 6; row++)
                    for (int column = 0; column < 4; column++)
                        if ((index + row * 3 + column) % 4 != 0 && row * 22f + 20f < height)
                            Fill(new Rect(x + 12f + column * 16f, bottom - height + 17f + row * 22f, 4f, 7f),
                                WithAlpha(p.Night > 0.2f ? p.Accent : p.Horizon, near ? 0.36f : 0.2f));
            }
        }

        private void ReadGaps(RunnerSession session)
        {
            gaps.Clear();
            if (session.State == RunState.Menu) return;
            for (int i = 0; i < session.Entities.Count; i++)
            {
                WorldEntity entity = session.Entities[i];
                if (!entity.Removed && entity.IsOpenGap && entity.X < Width && entity.X + entity.Width > 0f)
                    gaps.Add(new Vector2(Mathf.Max(0f, entity.X), Mathf.Min(Width, entity.X + entity.Width)));
            }
            gaps.Sort((a, b) => a.x.CompareTo(b.x));
        }

        private void DrawRoad(Palette p, float scroll, float speedRatio)
        {
            float left = 0f;
            for (int i = 0; i < gaps.Count; i++)
            {
                Vector2 gap = gaps[i];
                if (gap.x > left) DrawRoadSegment(left, gap.x, p, scroll, speedRatio);
                left = Mathf.Max(left, gap.y);
            }
            if (left < Width) DrawRoadSegment(left, Width, p, scroll, speedRatio);
            for (int i = 0; i < gaps.Count; i++)
            {
                Vector2 gap = gaps[i];
                DrawWarningEdge(gap.x - 14f, p.Accent);
                DrawWarningEdge(gap.y, p.Accent);
                Line(new Vector2(gap.x - 2f, GroundY + 6f), new Vector2(gap.x - 2f, GroundY + 46f), WithAlpha(p.Foundation, 0.65f), 3f);
                Line(new Vector2(gap.y + 2f, GroundY + 6f), new Vector2(gap.y + 2f, GroundY + 46f), WithAlpha(p.Foundation, 0.65f), 3f);
            }
        }

        private void DrawRoadSegment(float left, float right, Palette p, float scroll, float speedRatio)
        {
            float width = right - left;
            if (width <= 0f) return;
            GUI.BeginGroup(new Rect(left, GroundY, width, Height - GroundY));
            try
            {
                float platformBlend = gaps.Count > 0 ? 1f : Mathf.Clamp01(p.Skyway);
                bool flying = platformBlend >= .99f;
                float decorationScroll = DecorativeScroll(scroll);
                Fill(new Rect(0f, 0f, width, Height - GroundY), WithAlpha(p.Foundation, 1f - platformBlend));
                Fill(new Rect(0f, 0f, width, 39f), p.Foundation);
                // Two fixed tile grids fade in place. Switching tile width at
                // half of the map blend used to jump the whole road sideways.
                DrawRoadTiles(art.Road ?? art.PlatformLong, left, width, 680f, 114f,
                    decorationScroll, WithAlpha(p.Road, 1f - platformBlend));
                DrawRoadTiles(art.PlatformLong ?? art.Road, left, width, 360f, 105f,
                    decorationScroll, WithAlpha(p.Road, platformBlend));
                Fill(new Rect(0f, 0f, width, 3f), Color.Lerp(Hex(0xc7e9e1), p.Accent, p.Night * 0.5f));
                Fill(new Rect(0f, 4f, width, 3f), WithAlpha(Hex(0x172c42), 0.6f));
                if (p.Snow > 0.05f)
                {
                    // These layers are clipped to solid road segments, so an
                    // open hole can never acquire a painted snow floor.
                    Fill(new Rect(0f, 0f, width, 7f), WithAlpha(Hex(0xf2fbff), p.Snow));
                    Fill(new Rect(0f, 7f, width, 30f), WithAlpha(Hex(0x9ed8f1), p.Snow * 0.58f));
                    for (int i = 0; i < 10; i++)
                    {
                        float x = Repeat(i * 161f - decorationScroll, 1650f) - left;
                        Disc(new Rect(x, -3f, 51f + i % 3 * 17f, 12f), WithAlpha(Hex(0xf5fcff), p.Snow * 0.82f));
                        Line(new Vector2(x + 7f, 19f), new Vector2(x + 51f, 12f), WithAlpha(Hex(0xeafaff), p.Snow * 0.65f), 1.5f);
                        Line(new Vector2(x + 35f, 35f), new Vector2(x + 68f, 29f), WithAlpha(Hex(0x6eb7da), p.Snow * 0.38f), 1f);
                    }
                }
                // Road reflections move faster than the skyline, making acceleration visible.
                for (int i = 0; i < 12; i++)
                {
                    float x = Repeat(i * 129f - decorationScroll * 1.12f, 1500f) - left;
                    float y = 16f + i % 3 * 16f;
                    float streak = Mathf.Lerp(25f, 68f, Mathf.Clamp01(speedRatio - 1f));
                    Fill(new Rect(x, y, streak, i % 3 == 0 ? 2f : 1f), WithAlpha(p.Accent, 0.1f + 0.07f * p.Night + 0.05f * p.Rain));
                }
                if (!flying)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        float x = Repeat(i * 191f - decorationScroll * 1.35f, 1480f) - left;
                        Fill(new Rect(x, 112f + i % 2 * 17f, 44f + Mathf.Min(speedRatio, 2f) * 12f, 2f), WithAlpha(p.Accent, 0.08f));
                    }
                    if (p.Rain > 0.1f)
                    {
                        for (int i = 0; i < 7; i++)
                        {
                            float x = Repeat(i * 223f - decorationScroll, 1530f) - left;
                            Disc(new Rect(x, 9f + i % 3 * 10f, 80f + i % 3 * 18f, 7f), WithAlpha(p.Accent, p.Rain * 0.2f));
                        }
                    }
                }
            }
            finally { GUI.EndGroup(); }
        }

        private static void DrawRoadTiles(Texture2D texture, float left, float width,
            float tileWidth, float slabHeight, float scroll, Color tint)
        {
            if (tint.a <= .001f) return;
            float firstTile = Mathf.Floor((left + scroll) / tileWidth) * tileWidth - scroll - left;
            for (float x = firstTile; x < width; x += tileWidth)
            {
                if (texture != null)
                {
                    GUI.color = tint;
                    GUI.DrawTexture(new Rect(x, 0f, tileWidth + 1f, slabHeight), texture, ScaleMode.StretchToFill, true);
                }
                else
                {
                    Fill(new Rect(x, 3f, tileWidth + 1f, 62f), WithAlpha(Hex(0x40516c), tint.a));
                    Fill(new Rect(x + 30f, 32f, 70f, 4f), WithAlpha(Hex(0xc7e9e1), tint.a));
                }
            }
        }

        private static void DrawWarningEdge(float x, Color color)
        {
            Fill(new Rect(x, GroundY, 14f, 10f), color);
            Fill(new Rect(x + 2f, GroundY + 2f, 3f, 6f), Hex(0x263249));
            Fill(new Rect(x + 9f, GroundY + 2f, 3f, 6f), Hex(0x263249));
        }

        private void DrawEntities(RunnerSession session, Palette p, float time)
        {
            for (int entityIndex = 0; entityIndex < session.Entities.Count; entityIndex++)
            {
                WorldEntity entity = session.Entities[entityIndex];
                if (entity.Removed || entity.Kind == EntityKind.Gap || entity.X > Width + 100f || entity.X + entity.Width < -100f) continue;
                if (entity.Kind == EntityKind.CollapsingFloor)
                {
                    DrawCollapsingFloor(entity, p, time);
                    continue;
                }
                if (entity.Kind == EntityKind.FallingIce || entity.Kind == EntityKind.HeatVent || entity.Kind == EntityKind.StormDebris)
                {
                    DrawBiomeHazard(entity, time);
                    continue;
                }
                float bottom = GroundY - entity.Y;
                Rect rect = new Rect(entity.X, bottom - entity.Height, entity.Width, entity.Height);
                if (entity.Kind == EntityKind.Water || entity.Kind == EntityKind.HotDrink ||
                    entity.Kind == EntityKind.DoubleScore || entity.Kind == EntityKind.Magnet || entity.Kind == EntityKind.Shield)
                {
                    DrawPickup(rect, entity.Kind, time);
                    continue;
                }
                Texture2D texture = null;
                bool drawn = false;
                switch (entity.Kind)
                {
                    case EntityKind.House:
                        texture = entity.Variant % 3 == 0 ? art.House1 : entity.Variant % 3 == 1 ? art.House2 : art.House3;
                        GroundShadow(entity.X, entity.Width);
                        break;
                    case EntityKind.Hydrant:
                        texture = art.Hydrant;
                        GroundShadow(entity.X, entity.Width);
                        break;
                    case EntityKind.Plane:
                        texture = art.Plane;
                        Line(new Vector2(rect.xMax + 6f, rect.center.y), new Vector2(rect.xMax + 34f, rect.center.y), WithAlpha(p.Horizon, 0.65f), 3f);
                        break;
                    case EntityKind.Spike:
                        GroundShadow(entity.X, entity.Width);
                        GUI.color = Color.white;
                        if (!DrawAtlas(rect, 0)) GUI.DrawTexture(rect, spike, ScaleMode.StretchToFill, true);
                        drawn = true;
                        break;
                    case EntityKind.Saw:
                        Disc(new Rect(rect.x - 9f, rect.y - 9f, rect.width + 18f, rect.height + 18f), new Color(1f, 0.38f, 0.24f, 0.22f), true);
                        Matrix4x4 before = GUI.matrix;
                        try
                        {
                            RotateLocal(entity.Rotation, rect.center);
                            GUI.color = Color.white;
                            if (!DrawAtlas(rect, 1)) GUI.DrawTexture(rect, saw, ScaleMode.StretchToFill, true);
                        }
                        finally { GUI.matrix = before; }
                        drawn = true;
                        break;
                    case EntityKind.Barrier:
                        GroundShadow(entity.X, entity.Width);
                        GUI.color = Color.white;
                        if (!DrawAtlas(rect, entity.Variant % 2 == 0 ? 2 : 3)) DrawBarrier(rect, entity.Variant, p, time);
                        drawn = true;
                        break;
                    case EntityKind.Star:
                        texture = art.Star;
                        rect.y += Mathf.Sin(time * 3f + entity.Id * 0.9f) * 3f;
                        Disc(new Rect(rect.center.x - rect.width, rect.center.y - rect.height, rect.width * 2f, rect.height * 2f), new Color(1f, 0.8f, 0.27f, 0.3f), true);
                        if (entity.Id % 3 == 0)
                        {
                            float spark = 0.5f + Mathf.Sin(time * 4f + entity.Id) * 0.5f;
                            Fill(new Rect(rect.xMax + 3f, rect.y + 3f, 3f, 3f), new Color(1f, 0.95f, 0.7f, spark));
                        }
                        break;
                    case EntityKind.Heart:
                        texture = art.Heart;
                        rect.y += Mathf.Sin(time * 2.6f + entity.Id) * 4f;
                        float pulse = 1.8f + Mathf.Sin(time * 4f) * 0.15f;
                        Disc(new Rect(rect.center.x - rect.width * pulse / 2f, rect.center.y - rect.height * pulse / 2f, rect.width * pulse, rect.height * pulse), new Color(1f, 0.33f, 0.46f, 0.32f), true);
                        break;
                }
                if (drawn) continue;
                if (texture != null)
                {
                    GUI.color = Color.Lerp(Color.white, p.Backdrop, 0.1f * p.Night);
                    GUI.DrawTexture(rect, texture, ScaleMode.StretchToFill, true);
                }
                else Fill(rect, entity.Kind == EntityKind.Heart ? Hex(0xff657d) : entity.Kind == EntityKind.Star ? Hex(0xffd36f) : Hex(0x53758a));
            }
            GUI.color = Color.white;
        }

        private bool DrawAtlas(Rect target, int cell)
        {
            if (art.HazardAtlas == null) return false;
            // The catalog records tight UV bounds after the generated atlas is inspected.
            // Drawing those bounds keeps visible triangle/circle edges aligned to collisions.
            Rect uv = art.GetHazardUV(cell);
            GUI.DrawTextureWithTexCoords(target, art.HazardAtlas, uv, true);
            return true;
        }

        private bool DrawBiomeAtlas(Rect target, EntityKind kind, Color tint)
        {
            if (art.BiomeHazardAtlas == null) return false;
            GUI.color = tint;
            GUI.DrawTextureWithTexCoords(target, art.BiomeHazardAtlas, art.GetBiomeHazardUV(kind), true);
            return true;
        }

        private void DrawBiomeHazard(WorldEntity entity, float time)
        {
            // Core owns every position and phase. The only visual motion outside
            // these bounds is harmless warning dust and wind, never the body.
            Rect rect = new Rect(entity.X, GroundY - entity.Y - entity.Height, entity.Width, entity.Height);
            bool warning = entity.HazardPhase == 0;
            float progress = Mathf.Clamp01(entity.HazardWarning);
            if (entity.Kind == EntityKind.FallingIce)
            {
                if (warning)
                {
                    float pulse = 0.45f + Mathf.Sin(time * 11f) * 0.15f;
                    // A thin footprint and hanging support show where ice will
                    // land without painting an invisible damaging rectangle.
                    Fill(new Rect(rect.x - 10f, GroundY - 3f, rect.width + 20f, 4f),
                        WithAlpha(Hex(0x7edbff), pulse + progress * 0.25f));
                    Line(new Vector2(rect.x - 8f, rect.y - 5f), new Vector2(rect.xMax + 8f, rect.y - 5f), Hex(0x7895ac), 4f);
                    for (int i = 0; i < 3; i++)
                    {
                        float fall = Repeat(time * 2.1f + i * 0.31f, 1f);
                        Fill(new Rect(rect.x + rect.width * (0.25f + i * 0.25f), rect.yMax + 8f + fall * 22f,
                            3f, 3f), new Color(0.85f, 0.98f, 1f, (1f - fall) * (0.35f + progress * 0.55f)));
                    }
                }
                else GroundShadow(entity.X, entity.Width);

                Color tint = warning ? new Color(0.87f, 0.98f, 1f, 0.68f) : Color.white;
                if (!DrawBiomeAtlas(rect, entity.Kind, tint))
                {
                    GUI.color = tint;
                    GUI.DrawTexture(rect, ice, ScaleMode.StretchToFill, true);
                }
                if (warning)
                {
                    Color crack = WithAlpha(Hex(0x315a83), 0.45f + progress * 0.55f);
                    Vector2 start = new Vector2(rect.x + rect.width * 0.34f, rect.y + rect.height * 0.05f);
                    Vector2 middle = new Vector2(rect.x + rect.width * 0.51f, rect.y + rect.height * 0.22f);
                    Line(start, middle, crack, 1.5f);
                    Line(middle, new Vector2(rect.x + rect.width * 0.40f, rect.y + rect.height * (0.30f + progress * 0.16f)), crack, 1.5f);
                }
                GUI.color = Color.white;
                return;
            }

            if (entity.Kind == EntityKind.HeatVent)
            {
                // Hardware sits below the road. Only the shared active plume
                // can hurt the dinosaur, and its drawn height is the collider.
                Fill(new Rect(entity.X - 4f, GroundY + 1f, entity.Width + 8f, 13f), Hex(0x26364a));
                Fill(new Rect(entity.X, GroundY + 3f, entity.Width, 7f), Hex(0x657988));
                Color opening = warning ? Color.Lerp(Hex(0x77523c), Hex(0xffa846), progress)
                    : entity.HazardActive ? Hex(0xffdf87) : Hex(0x31485d);
                for (float x = entity.X + 5f; x < entity.X + entity.Width - 3f; x += 10f)
                    Fill(new Rect(x, GroundY + 2f, 5f, 7f), opening);
                if (warning)
                {
                    float pulse = 0.45f + Mathf.Sin(time * 12f) * 0.15f;
                    Fill(new Rect(entity.X, GroundY - 2f, entity.Width, 3f),
                        WithAlpha(Hex(0xff9b42), pulse + progress * 0.3f));
                    for (int i = 0; i < 4; i++)
                    {
                        float phase = Repeat(time * 1.8f + i * 0.24f, 1f);
                        Fill(new Rect(entity.X + entity.Width * (0.14f + i * 0.23f), GroundY - 3f - phase * 10f,
                            2f, 2f), new Color(1f, 0.57f, 0.21f, (1f - phase) * progress));
                    }
                }
                if (entity.HazardActive && entity.HazardHeight > 0f)
                {
                    Rect plume = new Rect(entity.X, GroundY - entity.Y - entity.HazardHeight, entity.Width, entity.HazardHeight);
                    if (!DrawBiomeAtlas(plume, entity.Kind, Color.white))
                    {
                        GUI.BeginGroup(plume);
                        try
                        {
                            for (int i = 0; i < 7; i++)
                            {
                                float fraction = i / 6f;
                                float inset = plume.width * ((i + 0.5f) / 14f);
                                Fill(new Rect(inset, plume.height * (1f - (i + 1f) / 7f), plume.width - inset * 2f,
                                    plume.height / 7f + 1f), Color.Lerp(Hex(0xff783b), Hex(0xffe8aa), 1f - fraction));
                            }
                        }
                        finally { GUI.EndGroup(); }
                    }
                }
                GUI.color = Color.white;
                return;
            }

            // The entire billboard stays axis-aligned with its collider.
            // Wind streaks carry the sense of tumbling without rotating the
            // visible body away from the live collision rectangle.
            for (int i = 0; i < 3; i++)
            {
                float y = rect.y + rect.height * (0.2f + i * 0.3f);
                Line(new Vector2(rect.xMax + 7f, y), new Vector2(rect.xMax + 33f + i * 9f, y - 4f),
                    new Color(0.85f, 0.96f, 1f, warning ? 0.24f : 0.48f), 1.5f);
            }
            if (warning)
            {
                Line(new Vector2(rect.center.x, rect.y - 20f), new Vector2(rect.center.x, rect.y), Hex(0x8499a9), 2f);
                Fill(new Rect(rect.x - 4f, rect.yMax + 3f, rect.width + 8f, 3f),
                    WithAlpha(Hex(0xffcc78), 0.35f + progress * 0.5f));
            }
            Color debrisTint = warning ? new Color(0.9f, 0.96f, 1f, 0.68f) : Color.white;
            if (!DrawBiomeAtlas(rect, entity.Kind, debrisTint))
            {
                Fill(rect, WithAlpha(Hex(0x233a50), debrisTint.a));
                Fill(new Rect(rect.x + 4f, rect.y + 4f, rect.width - 8f, rect.height - 8f),
                    WithAlpha(Hex(0xe4964b), debrisTint.a));
                Line(new Vector2(rect.x + 10f, rect.y + rect.height * 0.35f),
                    new Vector2(rect.xMax - 10f, rect.y + rect.height * 0.35f), Hex(0xfff0b6), 3f);
                Line(new Vector2(rect.x + 10f, rect.y + rect.height * 0.68f),
                    new Vector2(rect.xMax - 10f, rect.y + rect.height * 0.68f), Hex(0x31546b), 4f);
            }
            GUI.color = Color.white;
        }

        private void DrawCollapsingFloor(WorldEntity entity, Palette p, float time)
        {
            float progress = Mathf.Clamp01(entity.CollapseProgress);
            if (entity.IsOpenGap)
            {
                // The slab has already been removed by ReadGaps/DrawRoad.
                // Falling fragments remain below the collision surface.
                for (int i = 0; i < 4; i++)
                {
                    float fall = Repeat(time * 0.85f + entity.Id * 0.13f + i * 0.19f, 1f);
                    float x = entity.X + 12f + i * (entity.Width - 38f) / 3f;
                    Fill(new Rect(x, GroundY + 22f + fall * 100f, 24f, 10f),
                        WithAlpha(Hex(0x7b8b9c), (1f - fall) * 0.7f));
                }
                return;
            }

            Fill(new Rect(entity.X, GroundY + 5f, entity.Width, 25f), Hex(0x8693a0));
            Fill(new Rect(entity.X + 2f, GroundY, entity.Width - 4f, 5f), Hex(0xe0d6b0));
            DrawWarningEdge(entity.X, Hex(0xffcf75));
            DrawWarningEdge(entity.X + entity.Width - 14f, Hex(0xffcf75));
            Color crack = Color.Lerp(Hex(0x28384d), Hex(0xffa253), progress);
            for (int i = 0; i < 5; i++)
            {
                float x = entity.X + 24f + i * (entity.Width - 48f) / 4f;
                float y = GroundY + 4f;
                Line(new Vector2(x, y), new Vector2(x - 7f, y + 8f), crack, 1.5f + progress * 1.8f);
                Line(new Vector2(x - 7f, y + 8f), new Vector2(x + 5f, y + 15f), crack, 1.5f + progress * 1.8f);
                Line(new Vector2(x + 5f, y + 15f), new Vector2(x - 3f, y + 24f), crack, 1.5f + progress * 1.8f);
            }
            if (progress > 0.1f)
                Disc(new Rect(entity.X - 5f, GroundY + 10f, entity.Width + 10f, 19f),
                    WithAlpha(Hex(0xffb36b), progress * 0.22f), true);
        }

        private void DrawPickup(Rect rect, EntityKind kind, float time)
        {
            Color color = PickupColor(kind);
            float pulse = 0.21f + 0.08f * Mathf.Sin(time * 3.4f);
            Disc(new Rect(rect.x - rect.width * 0.35f, rect.y - rect.height * 0.3f,
                rect.width * 1.7f, rect.height * 1.6f), WithAlpha(color, pulse), true);
            if (art.PickupAtlas != null)
            {
                GUI.color = Color.white;
                GUI.DrawTextureWithTexCoords(rect, art.PickupAtlas, art.GetPickupUV(kind), true);
                return;
            }

            // Clear, shape-specific fallback icons keep supplies recognizable
            // before the generated atlas has finished importing in the Editor.
            GUI.BeginGroup(rect);
            try
            {
                float w = rect.width, h = rect.height;
                if (kind == EntityKind.Water)
                {
                    Fill(new Rect(w * 0.34f, 0f, w * 0.32f, h * 0.16f), Hex(0x2b638c));
                    Fill(new Rect(w * 0.23f, h * 0.15f, w * 0.54f, h * 0.8f), Hex(0xe2f8ff));
                    Fill(new Rect(w * 0.29f, h * 0.39f, w * 0.42f, h * 0.49f), color);
                    Fill(new Rect(w * 0.32f, h * 0.24f, w * 0.09f, h * 0.43f), Color.white);
                }
                else if (kind == EntityKind.HotDrink)
                {
                    Fill(new Rect(w * 0.17f, h * 0.35f, w * 0.58f, h * 0.52f), color);
                    Fill(new Rect(w * 0.21f, h * 0.35f, w * 0.5f, h * 0.1f), Hex(0x6a3926));
                    Line(new Vector2(w * 0.75f, h * 0.44f), new Vector2(w * 0.92f, h * 0.48f), color, 3f);
                    Line(new Vector2(w * 0.92f, h * 0.48f), new Vector2(w * 0.85f, h * 0.72f), color, 3f);
                    Line(new Vector2(w * 0.85f, h * 0.72f), new Vector2(w * 0.75f, h * 0.73f), color, 3f);
                    for (int i = 0; i < 2; i++)
                    {
                        float x = w * (0.32f + i * 0.23f);
                        float drift = Mathf.Sin(time * 2f + i) * w * 0.035f;
                        Line(new Vector2(x, h * 0.27f), new Vector2(x + drift, h * 0.1f), Hex(0xffeed7), 1.5f);
                    }
                }
                else if (kind == EntityKind.Magnet)
                {
                    Fill(new Rect(w * 0.16f, h * 0.18f, w * 0.22f, h * 0.6f), Hex(0xf36b7b));
                    Fill(new Rect(w * 0.62f, h * 0.18f, w * 0.22f, h * 0.6f), Hex(0x73c5ff));
                    Fill(new Rect(w * 0.29f, h * 0.68f, w * 0.42f, h * 0.2f), Hex(0xb8c5d9));
                    Fill(new Rect(w * 0.16f, h * 0.17f, w * 0.22f, h * 0.16f), Color.white);
                    Fill(new Rect(w * 0.62f, h * 0.17f, w * 0.22f, h * 0.16f), Color.white);
                }
                else if (kind == EntityKind.Shield)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        float half = w * (0.39f - Mathf.Max(0f, i - 2) * 0.055f);
                        Fill(new Rect(w * 0.5f - half, h * (0.12f + i * 0.09f), half * 2f, h * 0.1f), color);
                    }
                    Line(new Vector2(w * 0.5f, h * 0.24f), new Vector2(w * 0.5f, h * 0.65f), Color.white, 2f);
                }
                else
                {
                    Disc(new Rect(w * 0.05f, h * 0.05f, w * 0.9f, h * 0.9f), color);
                    Sign(new Rect(0f, h * 0.12f, w, h * 0.7f), "×2", Hex(0x5c3e23), Mathf.Max(11, (int)(h * 0.45f)));
                }
            }
            finally { GUI.EndGroup(); }
        }

        private static Color PickupColor(EntityKind kind)
        {
            switch (kind)
            {
                case EntityKind.Water: return Hex(0x58d9ff);
                case EntityKind.HotDrink: return Hex(0xffa05d);
                case EntityKind.Magnet: return Hex(0xf199d8);
                case EntityKind.Shield: return Hex(0x73baff);
                default: return Hex(0xffd975);
            }
        }

        private void DrawBarrier(Rect rect, int variant, Palette p, float time)
        {
            Fill(rect, Hex(0x17263d));
            if (variant % 2 == 0)
            {
                Fill(new Rect(rect.x + 4f, rect.y + 4f, rect.width - 8f, rect.height - 8f), Hex(0xf5b851));
                GUI.BeginGroup(new Rect(rect.x + 4f, rect.y + 4f, rect.width - 8f, rect.height - 8f));
                try
                {
                    for (float x = -rect.height; x < rect.width; x += 24f)
                        Line(new Vector2(x, rect.height), new Vector2(x + rect.height, 0f), Hex(0x2b3545), 9f);
                }
                finally { GUI.EndGroup(); }
            }
            else
            {
                Fill(new Rect(rect.x + 5f, rect.y + 5f, rect.width - 10f, rect.height - 10f), Hex(0x25526a));
                Color light = Color.Lerp(Hex(0x7bf3ee), p.Accent, 0.4f);
                Fill(new Rect(rect.x + 8f, rect.y + 8f, 4f, rect.height - 16f), light);
                Fill(new Rect(rect.xMax - 12f, rect.y + 8f, 4f, rect.height - 16f), light);
                float pulse = 0.4f + 0.25f * Mathf.Sin(time * 4f);
                for (float y = rect.y + 12f; y < rect.yMax - 8f; y += 12f)
                    Fill(new Rect(rect.x + 16f, y, rect.width - 32f, 2f), WithAlpha(light, pulse));
            }
        }

        private void GroundShadow(float x, float width)
        {
            Disc(new Rect(x - 7f, GroundY - 4f, width + 14f, 10f), new Color(0.03f, 0.09f, 0.15f, 0.2f), true);
        }

        private void DrawDino(RunnerSession session, float time)
        {
            float x = session.PlayerX;
            float y = session.PlayerY;
            float shadowScale = Mathf.Clamp(1f - y / 450f, 0.5f, 1f);
            bool diverOnShore = session.IsUnderwaterBoss && session.ArenaPhase == BossPhase.Victory && session.UnderwaterOnShore;
            float groundFootY = GroundY - (diverOnShore ? y : 0f);
            bool hasGround = session.IsUnderwaterBoss
                ? diverOnShore || (session.ArenaPhase == BossPhase.Intro && session.WaterDepth < .02f)
                : !session.IsFlyingBoss || (session.ArenaPhase != BossPhase.Fighting && session.TransitionElevation < .12f);
            bool overGap = false;
            for (int i = 0; i < gaps.Count; i++) if (x >= gaps[i].x && x <= gaps[i].y) overGap = true;
            if (hasGround && !overGap && (diverOnShore || y > -30f))
                Disc(new Rect(x - 39f * shadowScale, groundFootY - 6f,
                    78f * shadowScale, 13f * shadowScale), new Color(0.03f, 0.09f, 0.16f, 0.24f), true);
            bool running = session.State == RunState.Playing;
            bool facingLeft = session.FacingLeft;
            float bob = RunnerGeometry.GetPlayerBob(time, y, session.IsDucking, session.State);
            float width = session.IsDucking ? RunnerGeometry.PlayerDuckWidth : RunnerGeometry.PlayerStandingWidth;
            float height = session.IsDucking ? RunnerGeometry.PlayerDuckHeight : RunnerGeometry.PlayerStandingHeight;
            Rect rect = new Rect(x - width / 2f, GroundY - y - height + bob, width, height);
            Rect flightBody = rect;
            if (session.IsFlyingBoss && session.FlightDeviceCollected)
                DrawAttachedFlightDevice(session, rect, time);
            if (session.ShieldReady)
                Disc(new Rect(rect.x - 13f, rect.y - 10f, rect.width + 26f, rect.height + 22f),
                    new Color(0.3f, 0.8f, 1f, 0.22f), true);
            if (session.SkillActiveRemaining > 0f)
            {
                Color skillTint = session.CurrentCharacter == CharacterKind.Triceratops
                    ? new Color(1f, 0.77f, 0.28f, 0.3f) : new Color(0.65f, 0.65f, 1f, 0.25f);
                Disc(new Rect(rect.x - 11f, rect.y - 9f, rect.width + 22f, rect.height + 18f), skillTint, true);
                if (session.IsDashing)
                {
                    float behind = session.DashVelocity < 0f ? rect.xMax : rect.x;
                    float direction = session.DashVelocity < 0f ? 1f : -1f;
                    for (int i = 0; i < 3; i++)
                        Line(new Vector2(behind, rect.y + rect.height * (.3f + i * .2f)),
                            new Vector2(behind + direction * (27f + i * 12f), rect.y + rect.height * (.3f + i * .2f)),
                            new Color(.7f, .78f, 1f, .42f - i * .08f), 2f);
                }
            }
            if (session.InvincibleRemaining > 0f)
            {
                Disc(new Rect(rect.x - 14f, rect.y - 12f, rect.width + 28f, rect.height + 26f), new Color(0.65f, 1f, 0.87f, 0.3f), true);
                GUI.color = Mathf.FloorToInt(time * 12f) % 2 == 0 ? new Color(1f, 1f, 1f, 0.42f) : Color.white;
            }
            else GUI.color = Color.white;
            int frame = RunnerGeometry.GetPlayerFrame(session);
            Texture2D texture = art.GetCharacterTexture(session.CurrentCharacter, frame);
            Rect uv = art.GetCharacterUV(session.CurrentCharacter, frame);
            rect = art.GetCharacterRect(session.CurrentCharacter, frame, rect, facingLeft);
            if (facingLeft) uv = new Rect(uv.x + uv.width, uv.y, -uv.width, uv.height);
            if (texture != null)
                GUI.DrawTextureWithTexCoords(rect, texture, uv, true);
            else Fill(rect, Hex(0x7fbd72));
            if (session.IsFlyingBoss && session.FlightDeviceCollected)
                DrawFlightDeviceFront(session, flightBody);
            if (session.IsUnderwaterBoss && session.DivingHelmetEquipped)
                DrawDivingHelmet(session, flightBody, time);
            if (hasGround && running && y <= 1f && session.Elapsed > 0.5f)
            {
                for (int i = 0; i < 4; i++)
                {
                    float phase = Repeat(time * 4f + i * 0.25f, 1f);
                    float particleX = facingLeft ? x + 42f + phase * 58f : x - 42f - phase * 58f;
                    Fill(new Rect(particleX, groundFootY - 2f - phase * 9f, 5f - phase * 3f, 3f), new Color(0.89f, 0.94f, 0.91f, (1f - phase) * 0.55f));
                }
            }
            GUI.color = Color.white;
        }

        public void DrawCharacterPreview(CharacterKind kind, int frame, Rect body, bool facingLeft = false)
        {
            Color previous = GUI.color;
            try
            {
                GUI.color = Color.white;
                Texture2D texture = art.GetCharacterTexture(kind, frame);
                Rect uv = art.GetCharacterUV(kind, frame);
                Rect target = art.GetCharacterRect(kind, frame, body, facingLeft);
                if (facingLeft) uv = new Rect(uv.x + uv.width, uv.y, -uv.width, uv.height);
                if (texture != null) GUI.DrawTextureWithTexCoords(target, texture, uv, true);
                else Fill(body, Hex(0x7fbd72));
            }
            finally { GUI.color = previous; }
        }

        private void DrawDistrictAtmosphere(District district, Palette p, float scroll, float time, float speedRatio)
        {
            // These effects sit behind the road/player/hazards. Stronger late-run
            // wind reinforces speed without shifting any collision geometry.
            float rush = Mathf.Min(1.45f, 1f + Mathf.Sqrt(Mathf.Max(0f, speedRatio - 1f)) * 0.2f);
            switch (district)
            {
                case District.Day:
                    for (int i = 0; i < 9; i++)
                    {
                        float x = Repeat(i * 137.3f - scroll * 0.35f - time * 54f * rush, Width + 90f) - 45f;
                        float y = 275f + Repeat(i * 49.7f, 240f) + Mathf.Sin(time * 1.7f + i) * 11f;
                        Color leaf = WithAlpha(i % 3 == 0 ? Hex(0xb98e54) : Hex(0x9fc47b), 0.42f);
                        Line(new Vector2(x, y), new Vector2(x + 7f, y - 3f), leaf, 3f);
                        if (i % 3 == 0)
                            Line(new Vector2(x + 17f, y + 5f), new Vector2(x + 52f * rush, y + 3f), WithAlpha(p.Horizon, 0.18f), 1f);
                    }
                    break;
                case District.Sunset:
                    // Heat is suggested by wavering highlights in the backdrop,
                    // never by warping the foreground or moving a hitbox.
                    for (int i = 0; i < 7; i++)
                    {
                        float y = 431f + i * 14f;
                        float offset = Mathf.Sin(time * .7f + i * 0.8f) * 8f;
                        Fill(new Rect(offset - 30f, y, Width + 60f, 2f), WithAlpha(Hex(0xffd7aa), 0.025f + i * 0.003f));
                    }
                    for (int i = 0; i < 18; i++)
                    {
                        float phase = Repeat(time * (0.11f + i % 4 * 0.02f) + i * 0.171f, 1f);
                        float x = Repeat(i * 91.7f - scroll * 0.12f - phase * 95f, Width);
                        float y = 539f - phase * 270f;
                        float alpha = Mathf.Sin(phase * 3.1415927f) * 0.38f;
                        Fill(new Rect(x, y, 2f + i % 2, 3f), WithAlpha(Hex(0xffd28b), alpha));
                    }
                    break;
                case District.Night:
                    for (int i = 0; i < 7; i++)
                    {
                        float x = Repeat(i * 223f - scroll * 0.17f, Width + 210f) - 100f;
                        float y = 259f + i % 3 * 67f;
                        float pulse = 0.5f + Mathf.Sin(time * 1.25f + i * 1.9f) * 0.18f;
                        Color neon = i % 2 == 0 ? Hex(0x73f8db) : Hex(0xb4a3ff);
                        Disc(new Rect(x - 15f, y - 15f, 120f, 51f), WithAlpha(neon, pulse * 0.14f), true);
                        Fill(new Rect(x, y, 78f, 2f), WithAlpha(neon, pulse * 0.5f));
                    }
                    break;
                case District.Skyway:
                    for (int i = 0; i < 7; i++)
                    {
                        float x = Repeat(i * 181.3f - time * 95f * rush - scroll * 0.05f, Width + 300f) - 150f;
                        float y = 163f + Repeat(i * 57f, 315f);
                        float span = (48f + i % 3 * 16f) * rush;
                        Line(new Vector2(x, y), new Vector2(x + span, y - 5f), WithAlpha(Hex(0xf4fcff), 0.14f), 2f);
                        Line(new Vector2(x + 15f, y + 9f), new Vector2(x + span * 0.65f, y + 5f), WithAlpha(p.Horizon, 0.14f), 1f);
                    }
                    break;
                case District.Storm:
                    for (int i = 0; i < 6; i++)
                    {
                        float x = Repeat(i * 173f - time * 105f * rush, Width + 180f) - 90f;
                        float y = 180f + Repeat(i * 43f, 290f);
                        Line(new Vector2(x, y), new Vector2(x + 64f, y - 14f), WithAlpha(p.Horizon, 0.13f), 2f);
                    }
                    break;
            }
        }

        private static void DrawWind(RunnerSession session, float time)
        {
            if (session.CurrentDistrict != District.Skyway) return;
            float strength = Mathf.Clamp01(session.WindStrength);
            for (int i = 0; i < 7; i++)
            {
                float x = Repeat(i * 147f - time * (105f + strength * 165f), Width + 260f) - 130f;
                float y = 235f + (i * 49 % 280);
                float span = 36f + strength * 60f + i % 3 * 9f;
                Color tint = new Color(0.9f, 0.98f, 1f, 0.1f + strength * 0.16f);
                Line(new Vector2(x + span, y), new Vector2(x, y), tint, 1.5f);
                if (strength > 0.35f && i % 3 == 0)
                {
                    Line(new Vector2(x + 8f, y - 4f), new Vector2(x, y), tint, 1.5f);
                    Line(new Vector2(x + 8f, y + 4f), new Vector2(x, y), tint, 1.5f);
                }
            }
        }

        private void DrawWeather(Palette p, float scroll, float time)
        {
            if (p.Snow > 0.05f)
            {
                for (int i = 0; i < 58; i++)
                {
                    float x = Repeat(i * 83.7f - time * (45f + i % 5 * 8f)
                        + Mathf.Sin(time * 0.8f + i) * 14f, Width + 30f) - 15f;
                    float y = Repeat(i * 47.3f + time * (75f + i % 7 * 10f), Height + 40f) - 20f;
                    float size = 2f + i % 3;
                    Color flake = new Color(0.94f, 0.98f, 1f, p.Snow * (0.5f + i % 3 * 0.1f));
                    Fill(new Rect(x, y, size, size), flake);
                    if (i % 6 == 0)
                    {
                        Fill(new Rect(x - 2f, y + size / 2f - 0.5f, size + 4f, 1f), flake);
                        Fill(new Rect(x + size / 2f - 0.5f, y - 2f, 1f, size + 4f), flake);
                    }
                }
            }
            if (p.Sunset > 0.1f)
                Disc(new Rect(855f, 170f, 550f, 550f), new Color(1f, 0.75f, 0.43f, 0.12f * p.Sunset), true);
            if (p.Rain > 0.05f)
            {
                int count = Mathf.RoundToInt(67f * p.Rain);
                for (int i = 0; i < count; i++)
                {
                    float x = Repeat(i * 87.7f - time * 110f, Width + 80f) - 40f;
                    float y = Repeat(i * 63.3f + time * (300f + i % 4 * 18f), 600f) - 30f;
                    float length = 14f + i % 4 * 5f;
                    Line(new Vector2(x, y), new Vector2(x - 6f, y + length), new Color(0.83f, 0.94f, 1f, 0.17f + i % 3 * 0.04f), i % 4 == 0 ? 2f : 1f);
                }
                for (int i = 0; i < 12; i++)
                {
                    float x = Repeat(i * 111f - scroll, Width);
                    float phase = Repeat(time * 1.7f + i * 0.17f, 1f);
                    if (phase >= 0.3f) continue;
                    bool aboveGap = false;
                    for (int j = 0; j < gaps.Count; j++) if (x >= gaps[j].x && x <= gaps[j].y) aboveGap = true;
                    if (!aboveGap)
                    {
                        float spread = phase * 20f;
                        Line(new Vector2(x - spread, GroundY - 1f), new Vector2(x - spread - 3f, GroundY - 5f), WithAlpha(p.Horizon, (0.3f - phase) * p.Rain), 1.5f);
                        Line(new Vector2(x + spread, GroundY - 1f), new Vector2(x + spread + 3f, GroundY - 5f), WithAlpha(p.Horizon, (0.3f - phase) * p.Rain), 1.5f);
                    }
                }
            }
            if (p.Skyway > 0.1f)
            {
                for (int i = 0; i < 5; i++)
                {
                    float x = Repeat(i * 191f - time * 95f, Width + 220f) - 110f;
                    float y = 205f + i % 3 * 53f;
                    Line(new Vector2(x, y), new Vector2(x + 64f, y - 7f), WithAlpha(p.Horizon, p.Skyway * 0.24f), 2f);
                }
            }
        }

        private static void DrawLightning(RunnerSession session, float rainBlend)
        {
            var lightning = RunnerWeather.GetLightning(session.CurrentDistrict, session.DistrictElapsed);
            float strength = Mathf.Clamp01(lightning.Amount) * Mathf.Clamp01(rainBlend);
            if (strength <= 0f) return;
            // The storm's repeated dark/bright pulse is a gameplay challenge.
            // Only its map-entry/exit weight fades, not its in-map intensity.
            Fill(new Rect(0f, 0f, Width, Height), new Color(0.75f, 0.87f, 1f, strength * 0.55f));
            float boltX = Mathf.Clamp(lightning.BoltX, 100f, Width - 100f);
            Vector2 from = new Vector2(boltX, 124f);
            Color halo = new Color(0.56f, 0.77f, 1f, strength * 0.35f);
            Color core = new Color(0.92f, 0.97f, 1f, strength * 0.9f);
            for (int i = 1; i <= 6; i++)
            {
                float zigzag = ((lightning.StrikeId + i * 17) % 5 - 2) * 15f;
                Vector2 to = new Vector2(boltX + zigzag, 124f + i * 39f);
                Line(from, to, halo, 9f);
                Line(from, to, core, 2.5f);
                if (i == 3 || i == 5)
                {
                    float side = i == 3 ? -1f : 1f;
                    Vector2 branch = new Vector2(to.x + side * 38f, to.y + 20f);
                    Vector2 tip = new Vector2(branch.x - side * 11f, branch.y + 29f);
                    Line(to, branch, halo, 5f);
                    Line(to, branch, core, 1.5f);
                    Line(branch, tip, core, 1.5f);
                }
                from = to;
            }
        }

        private void DrawDarkness(RunnerSession session)
        {
            float amount = Mathf.Clamp01(session.DarknessAmount);
            if (amount > 0f)
            {
                // The blackout is intentionally fully opaque at its peak. Draw
                // nothing from the world above it; HUD/controls are a later pass.
                Fill(new Rect(0f, 0f, Width, Height), new Color(0f, 0f, 0f, amount));
                return;
            }
            if (session.State != RunState.Playing) return;
            if (session.BlackoutWarning)
            {
                Fill(new Rect(399f, 130f, 482f, 39f), new Color(0.06f, 0.10f, 0.16f, 0.93f));
                Sign(new Rect(409f, 133f, 462f, 31f), "SẮP TỐI NGẮN · GHI NHỚ VỊ TRÍ BẪY", Hex(0xffcf8b), 15);
            }
        }

        private void Sign(Rect rect, string text, Color color, int size)
        {
            if (signStyle == null) signStyle = new GUIStyle { font = art.Font, alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold };
            signStyle.fontSize = size;
            signStyle.normal.textColor = color;
            GUI.color = Color.white;
            GUI.Label(rect, text, signStyle);
        }

        private void Cloud(float x, float y, float scale, Color color)
        {
            Disc(new Rect(x, y + 17f * scale, 106f * scale, 34f * scale), color);
            Disc(new Rect(x + 20f * scale, y, 55f * scale, 55f * scale), color);
            Disc(new Rect(x + 60f * scale, y + 10f * scale, 43f * scale, 43f * scale), color);
        }

        private void Disc(Rect rect, Color color, bool soft = false)
        {
            GUI.color = color;
            GUI.DrawTexture(rect, soft ? glow : circle, ScaleMode.StretchToFill, true);
        }

        private static void Fill(Rect rect, Color color)
        {
            GUI.color = color;
            GUI.DrawTexture(rect, Texture2D.whiteTexture);
        }

        private static void Line(Vector2 from, Vector2 to, Color color, float thickness)
        {
            Vector2 delta = to - from;
            if (delta.sqrMagnitude < 0.001f) return;
            // Most road, machinery and warning details are axis-aligned.
            // Their exact rectangle needs no angle, quaternion or GUI matrix
            // changes; keep the general transform only for slanted segments.
            if (delta.y == 0f)
            {
                Fill(new Rect(Mathf.Min(from.x, to.x), from.y - thickness * .5f,
                    Mathf.Abs(delta.x), thickness), color);
                return;
            }
            if (delta.x == 0f)
            {
                Fill(new Rect(from.x - thickness * .5f, Mathf.Min(from.y, to.y),
                    thickness, Mathf.Abs(delta.y)), color);
                return;
            }
            Matrix4x4 previous = GUI.matrix;
            try
            {
                RotateLocal(Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg, from);
                Fill(new Rect(from.x, from.y - thickness * 0.5f, delta.magnitude, thickness), color);
            }
            finally { GUI.matrix = previous; }
        }

        private static void RotateLocal(float angle, Vector2 pivot)
        {
            // Compose in virtual coordinates BEFORE the canvas-to-screen
            // transform. GUIUtility.RotateAroundPivot prepends a screen-space
            // rotation, which displaces the saw when the Game view is scaled.
            GUI.matrix = GUI.matrix
                * Matrix4x4.TRS(new Vector3(pivot.x, pivot.y, 0f), Quaternion.Euler(0f, 0f, angle), Vector3.one)
                * Matrix4x4.TRS(new Vector3(-pivot.x, -pivot.y, 0f), Quaternion.identity, Vector3.one);
        }

        private static Color Hex(uint rgb)
        {
            return new Color(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, 1f);
        }

        private static Color WithAlpha(Color color, float alpha) { color.a = alpha; return color; }
        private static float Repeat(float value, float length) { return value - Mathf.Floor(value / length) * length; }

        private static Texture2D MakeCircle(bool soft)
        {
            const int size = 64;
            Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.name = soft ? "CityDino soft glow" : "CityDino disc";
            texture.filterMode = FilterMode.Bilinear;
            texture.wrapMode = TextureWrapMode.Clamp;
            Color[] pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    float dx = (x + 0.5f - size / 2f) / (size / 2f);
                    float dy = (y + 0.5f - size / 2f) / (size / 2f);
                    float distance = Mathf.Sqrt(dx * dx + dy * dy);
                    float alpha = soft ? Mathf.Pow(Mathf.Clamp01(1f - distance), 1.8f) : Mathf.Clamp01((1f - distance) * 22f);
                    pixels[y * size + x] = new Color(1f, 1f, 1f, alpha);
                }
            texture.SetPixels(pixels);
            texture.Apply(false, true);
            return texture;
        }

        private static Texture2D MakeSpike()
        {
            const int size = 64;
            Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.name = "CityDino spike fallback";
            texture.filterMode = FilterMode.Point;
            texture.wrapMode = TextureWrapMode.Clamp;
            Color[] pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    float py = (y + 0.5f) / size;
                    float px = Mathf.Abs((x + 0.5f) / size - 0.5f);
                    float half = (1f - py) * 0.5f;
                    Color color = Color.clear;
                    if (px <= half)
                    {
                        bool edge = half - px < 0.055f || py < 0.065f;
                        color = edge ? Hex(0x203249) : Color.Lerp(Hex(0xff7359), Hex(0xffe5a1), py);
                    }
                    pixels[y * size + x] = color;
                }
            texture.SetPixels(pixels);
            texture.Apply(false, true);
            return texture;
        }

        private static Texture2D MakeSaw()
        {
            const int size = 128;
            Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.name = "CityDino saw fallback";
            texture.filterMode = FilterMode.Bilinear;
            texture.wrapMode = TextureWrapMode.Clamp;
            Color[] pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    double dx = (x + 0.5 - size / 2.0) / (size / 2.0);
                    double dy = (y + 0.5 - size / 2.0) / (size / 2.0);
                    double radius = Math.Sqrt(dx * dx + dy * dy);
                    double edge = 0.83 + 0.14 * Math.Cos(Math.Atan2(dy, dx) * 12);
                    Color color = Color.clear;
                    if (radius <= edge)
                    {
                        color = edge - radius < 0.055 ? Hex(0x26354b) : Hex(0xc4dae0);
                        if (radius < 0.63) color = Hex(0x738c9e);
                        if (radius < 0.47) color = Hex(0xffa85f);
                        if (radius < 0.27) color = Hex(0x26354b);
                        if (radius < 0.13) color = Hex(0x8df3ec);
                    }
                    pixels[y * size + x] = color;
                }
            texture.SetPixels(pixels);
            texture.Apply(false, true);
            return texture;
        }

        private static Texture2D MakeIcicle()
        {
            const int size = 64;
            Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.name = "CityDino icicle fallback";
            texture.filterMode = FilterMode.Point;
            texture.wrapMode = TextureWrapMode.Clamp;
            Color[] pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    float fraction = (y + 0.5f) / size;
                    float distance = Mathf.Abs((x + 0.5f) / size - 0.5f);
                    float half = fraction * 0.5f;
                    Color tint = Color.clear;
                    if (distance <= half)
                        tint = half - distance < 0.05f || fraction > 0.94f ? Hex(0x4a8db7)
                            : Color.Lerp(Hex(0x92dcfa), Hex(0xedfcff), fraction);
                    pixels[y * size + x] = tint;
                }
            texture.SetPixels(pixels);
            texture.Apply(false, true);
            return texture;
        }

        public void Dispose()
        {
            if (circle != null) UnityEngine.Object.Destroy(circle);
            if (glow != null) UnityEngine.Object.Destroy(glow);
            if (spike != null) UnityEngine.Object.Destroy(spike);
            if (saw != null) UnityEngine.Object.Destroy(saw);
            if (ice != null) UnityEngine.Object.Destroy(ice);
        }
    }
}
